PETCARE - PROJETO ACADÊMICO
Grupo: Lucas, Gabriel Luan e Leonardo - Turma 3A

COMO ABRIR
1. Abra a pasta petcare.
2. Dê dois cliques no arquivo index.html.
3. O site abrirá no navegador e funciona sem instalar nada.

FUNCIONALIDADES
- Página inicial e catálogo de serviços.
- Cadastro, edição e exclusão de pets (CRUD).
- Criação, conclusão e remoção de agendamentos.
- Dados persistidos no navegador com localStorage.
- Layout responsivo para computador e celular.

TECNOLOGIAS
HTML, CSS e JavaScript puro.

EXPLICAÇÃO TÉCNICA
O front-end apresenta e coleta as informações. O JavaScript executa as regras do sistema e manipula os dados. Para manter o projeto simples e executável sem servidor, a persistência usa localStorage. Em uma versão comercial, seria usado back-end, banco de dados e autenticação.
